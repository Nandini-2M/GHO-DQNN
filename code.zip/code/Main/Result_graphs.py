# Imports PIL module
from PIL import Image
# open method used to open different extension image file
im1 = Image.open(r"E:\Deepika\Paper_works\Nandini muppalla (236103)-Paper 1 (Class II)\236103_nm\Result\acc_tr.jpg")
im2 = Image.open(r"E:\Deepika\Paper_works\Nandini muppalla (236103)-Paper 1 (Class II)\236103_nm\Result\sen_tr.jpg")
im3 = Image.open(r"E:\Deepika\Paper_works\Nandini muppalla (236103)-Paper 1 (Class II)\236103_nm\Result\spe_tr.jpg")
im4 = Image.open(r"E:\Deepika\Paper_works\Nandini muppalla (236103)-Paper 1 (Class II)\236103_nm\Result\acc_tr2.jpg")
im5 = Image.open(r"E:\Deepika\Paper_works\Nandini muppalla (236103)-Paper 1 (Class II)\236103_nm\Result\sen_tr2.jpg")
im6 = Image.open(r"E:\Deepika\Paper_works\Nandini muppalla (236103)-Paper 1 (Class II)\236103_nm\Result\spe_tr2.jpg")
im7 = Image.open(r"E:\Deepika\Paper_works\Nandini muppalla (236103)-Paper 1 (Class II)\236103_nm\Result\acc_perf.jpg")
im8 = Image.open(r"E:\Deepika\Paper_works\Nandini muppalla (236103)-Paper 1 (Class II)\236103_nm\Result\sen_perf.jpg")
im9 = Image.open(r"E:\Deepika\Paper_works\Nandini muppalla (236103)-Paper 1 (Class II)\236103_nm\Result\spe_perf.jpg")
im10 = Image.open(r"E:\Deepika\Paper_works\Nandini muppalla (236103)-Paper 1 (Class II)\236103_nm\Result\acc_perf2.jpg")
im11 = Image.open(r"E:\Deepika\Paper_works\Nandini muppalla (236103)-Paper 1 (Class II)\236103_nm\Result\sen_perf2.jpg")
im12 = Image.open(r"E:\Deepika\Paper_works\Nandini muppalla (236103)-Paper 1 (Class II)\236103_nm\Result\spe_perf2.jpg")

# This method will show image in any image viewer
im1.show()
im2.show()
im3.show()
im4.show()
im5.show()
im6.show()
im7.show()
im8.show()
im9.show()
im10.show()
im11.show()
im12.show()
