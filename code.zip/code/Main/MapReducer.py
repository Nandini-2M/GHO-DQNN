import numpy as np
import pandas as pd
from Main import  Fusion
import Proposed.dqnn.DQNN
import scipy.stats as stats

def zscore(Data):
    zscores = stats.zscore(Data)
    return zscores


# mapper process: split the data to the size of mapper
def mapper(data, target, dts):

    #apply preprocessing
    ######### zscore Normalization ###########
    pre_processed_data =zscore(data)

    ######### Feature Fusion (Czekanowski) ###########
    sel_feature = Fusion.feature_fusion(pre_processed_data, target)


    return sel_feature



# Reducer process
def reducer(fused_data,target,dts,tr_per,acc,sen,spe):
    merge = []
    for i in range(len(fused_data)):
        merge.append(fused_data[i])
    if dts == 'covid_ml':
        np.savetxt('Processed_fused_data.csv', merge, delimiter=',',  # save the fused dataset
                   fmt='%s')
    else:
        np.savetxt('Processed_fused_data.csv', merge, delimiter=',',  # save the fused dataset
                   fmt='%s')

    Proposed.dqnn.DQNN.classify(merge, target, tr_per, acc, sen, spe)
    return fused_data


# Feature main
def Mapper_phase(data, target, ms):
    feature = mapper(data, target, ms)
    return feature

def Map_Reducer(feat,target,lab,dts,ls,acc,sen,spe):
    ms = len(feat)
    print("\t >>Mapper Phase")
    sel_feat = Mapper_phase(feat,target,dts)
    print("\t >>Reducer Phase")
    reducer(sel_feat,lab,dts,ls,acc,sen,spe)
    return 0









