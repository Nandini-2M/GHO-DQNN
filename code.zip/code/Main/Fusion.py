import sys, numpy as np
from Main import Sort,DRN
import pandas as pd

def Czekanowski(P,Q):
    h_value = []
    for i in range(len(P)):
        dist = 2 * (np.minimum(P[i],Q[i])) / (P[i] + Q[i])
        h_value.append(dist)
    return h_value

def feature_fusion(data,clas):

    # arrange features by Czekanowski distance
    f = Sort.by_find_Czekanowski(data,clas)

    T = len(f)
    F_new, l = [], round(T)
    S = (len(data[0]))
    # train_x, train_y = preprocess(data, clas)
    beta = DRN.classify(data, clas, np.array(data))  # beta value prediction by Deep residual Network

    for m in range(len(f)):  # data size
        FF = []
        for n in range(S):  # n_features to be fused
            summ, i, p = 0, n, 1
            while p <= l:  # n attributed to fused as 1
                summ += ((beta[m] / p)*f[m][i])
                if (i + S) < 1: i = i + S
                else: p += l  # last set
                p += 1
            FF.append(summ)
        F_new.append(FF)
        # F_new.append(feat)
    return F_new
