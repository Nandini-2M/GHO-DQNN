import csv
import numpy as np
from Main import DFC,MapReducer


def read(dts):  # function  to read data
    data = []  # create empty array
    with open('dataset.csv', 'r') as file:  # to open a file
        reader = csv.reader(file)  # read a file
        for row in reader:
            data.append(row)  # append the data to the file
    data = data[1:]  # remove the first row in a file
    return data

def preprocess_(data,dts):  # function to preprocess
    F1 = DFC.DFC_m(n_clusters=15)
    data = data.astype('float')
    F1.fit(data)
    centers = F1.centers
    idx_ctr = np.argsort(np.transpose(centers))[0]
    F1.u = F1.u[:, idx_ctr]
    labels = F1.u.argmax(axis=1)
    datanew = F1.u
    return datanew,labels

def preprocess(data, dts):  # function to preprocess
    def string_conversion(data, uni):
        for i in range(len(data)):  # loop for the array data
            for j in range(len(uni)):  # loop for the array uni
                if (data[i] == uni[j]):  # compare with the array and uni
                    data[i] = j
        return data

    def find_missing(data):
        datas = []
        for i in range(len(data)):
            temp = []
            for j in range(len(data[i])):
                if data[i][j] == '':  # replace ' ' by '-1000'
                    data[i][j] = '-1000'  # for missing value imputation
                temp.append(int(float(data[i][j])))
            datas.append(temp)

        n_data = []
        for i in range(len(data)):
            temp = []
            for j in range(len(data[i])):
                if (data[i][j] != '-1000'):  # except -1000 add all other values to a list
                    temp.append(int(float(data[i][j])))
                else:
                    temp.append(0)  # to get mean of other values in column
            n_data.append(temp)
        n_data = np.array(n_data)
        Avg = np.mean(n_data, axis=0)  # average of column values
        for i in range(len(data)):
            for j in range(len(data[i])):
                if (data[i][j] == '-1000'):  # replace '-1000' by calculated average values
                    data[i][j] = int(float(Avg[j]))  # missing values are replaced by column average
                else:
                    data[i][j] = int(float(data[i][j]))
        data = np.array(data)
        return data

    data = np.array(data)  # to convert the data as array
    data = np.transpose(data)  # to transpose the data in a file
    ind = [0, 2, 3, 4, 5, 6, 7, 8, 9, 11, 12, 13, 14, 17, 18, 19, 20, 21,
           22]  # column which we want to change in covid_ml
    for i in range(len(data)):
        if (i in ind):  # check the condition with the array ind
            uni = np.unique(data[i])  # to find the unique value
            data[i] = string_conversion(data[i], uni)  # function call
    data = np.transpose(data)  # transpose the converted string
    for j in range(len(data)):
        for k in range(len(data[j])):
            if data[j][k] == 'NA':  # change the NA as 0
                data[j][k] = 0
    target = data[:, 9]   #select the 9th colunm as target
    data = np.delete(data, 9, 1)  # delete the 9th column from dataset
    data = data.astype('float')  # to change the string datatype to float
    target = target.astype('int')  # to change the string datatype to int

    np.savetxt('preprocessed_data.csv', data, delimiter=',',fmt='%s')          # save the dataset into a given location
    np.savetxt('target.csv', target, delimiter=',',fmt='%s')        #save the target into given location
    return data, target

tr_ep=90
acc, sen, spe = [], [], []  # create a empty array
print("\n Reading input data..")
data = read(dts)  # read the data type
Data, target = preprocess(data, dts)  # function call
print("\n FCM..")
# FCM
cluster_data, cluster_label = preprocess_(Data, dts)
print("\n Mapper Reduce")
MapReducer.Map_Reducer(cluster_data,cluster_label,target,dts,tr_ep,acc,sen,spe)
print("\n Please wait..")



