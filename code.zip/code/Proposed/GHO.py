import random
import numpy as np

def initialize(nn, l, u):
    ran_data = []
    for i in range(nn):
        tem = []
        for j in range(nn):
            tem.append(random.random() * (u - l) + l)
        ran_data.append(tem)
    return ran_data

def brownian_motion(x):                                                         # eq(4)
    brownian = []
    for i in range(len(x)):
        brown = (1 / (np.sqrt(2 * np.pi))) * (np.exp (-(np.square(x[i])/2)))
        brownian.append(brown)
    return brownian

def levy_distribution(x):                                                       # eq(5)
    LL = []
    sig = random.uniform(0.3,1.99)
    for i in range(len(x)):
        levy = abs(x[i] ** (1-sig))
        LL.append(levy)
    return LL

def func(soln):

    fit = []
    for i in range(len(soln)):
        fit.append(random.random()) # random fit
    return fit

def update_gazelle(s, elite, R, x):
    Rb = brownian_motion(x)
    R4 = random.uniform(0,1)
    C = random.uniform(0,1)
    Z = random.uniform(0,1)
    update_gazelle = []
    for i in range(len(x)):
        # gaz = x[i] + s * R * Rb[i] * (elite[i] - Rb[i] * x[i])
        gaz = (1 / C * Z * np.cos(2 * np.pi * R4) + 1 - s * R * Rb[i]) * (x[i][i] * (1 + C * Z * np.cos (2 * np.pi * R4)) * (1 - s * R * Rb[i]) + (s * R * Rb[i] * elite[i]) * (C * Z * np.cos (2 * np.pi * R4)))
        update_gazelle.append(gaz)
    return update_gazelle

def update_gazelle2(s, elite, R, gazelle, newe):
    Rl = levy_distribution(gazelle)
    update_gazelle = []
    for i in range(len(gazelle)):
        gaz = gazelle[i] + s * newe * R * Rl[i] * (elite[i] - Rl[i] * gazelle[i])
        update_gazelle.append(gaz)
    return update_gazelle

def update_gazelle3(s, elite, R, gazelle, newe, cf):
    Rl = levy_distribution(gazelle)
    update_gazelle = []
    for i in range(len(gazelle)):
        gaz = gazelle[i] + s * newe * cf * R * Rl[i] * (elite[i] - Rl * gazelle[i])
        update_gazelle.append(gaz)
    return update_gazelle

def psrs_gaz(gazelle, lb, ub, R, cf, u):
    psrs_gazz = []
    for i in range(len(gazelle)):
        gazz = gazelle[i] + cf * (lb + R * (ub - lb)) * u
        psrs_gazz.append(gazz)
    return psrs_gazz

def psrs_gaz2(gazelle, psr, r):
    r1 = random.randint(1,10)
    r2 = random.randint(1, 10)
    psrs_gazz = []
    for i in range(len(gazelle)):
        gazz = gazelle[i] + (psr * (1 - r) + r) * (r1 - r2)
        psrs_gazz.append(gazz)
    return psrs_gazz

def algm():

    s= [0,1]
    µ= [-1,1]
    S= 88
    PSRs=0.34
    nn, l, u = 10, 0, 10
    R = random.randint(0,1)
    r = random.randint(0,1)
    g, max_itr = 0, 10

    pop = initialize(nn,l,u)
    if r<0.2: U =0
    else: U = 1

    while g<max_itr:
        fit = func(pop)
        elite = initialize(nn,l,u)
        CF = (1 - g/max_itr) ** (2*g / max_itr)
        if r<2:
            new_gazelle = update_gazelle(S, elite, R, pop)                      # eq(8)
        else:
            if(np.mod(g,2)==0):µ = -1
            else:µ = 1
            new_gazelle = update_gazelle2(S, elite, R, pop,µ )                  # eq(9)
            new_gazelle = update_gazelle3(S, elite, R, pop, µ, CF)              # eq(10)

        if r<=PSRs:                                                             # eq(11)
            updated_gaz = psrs_gaz(new_gazelle, l, u, R, CF, U)
        else:
            updated_gaz = psrs_gaz2(new_gazelle, PSRs, r)
        g = g + 1

    best_soln = min(updated_gaz[1])

    return abs(best_soln)