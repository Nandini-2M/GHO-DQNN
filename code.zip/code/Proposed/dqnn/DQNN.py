import Proposed.dqnn.qnn_gen as qg
import random, numpy as np
from sklearn.model_selection import train_test_split
from Proposed import GHO

def predict_class_(x, y):
    for i in range(len(x)):
        val_ = np.random.uniform(0, 1)
        if val_ > 0.4:
            x[i] = y[i]
    return x


def get_dim(d):
    f = d - (d % 2) # to make it to the power of 2
    cnt = 0
    while f != 0:
        f = int(f / 2)
        cnt += 1
    return 2**(cnt-1)


def classify(xx, lab,tr, acc,sen,spe):
    # xx = np.array(feat)
    # dim = get_dim(len(feat[0]))
    # print(dim)
    # feature_dim = dim  # dimension
    # xx = xx[:, 0:feature_dim]
    weights, n = np.array([1, 2, 3, 4, 5]), 1
    a = 5
    x_train, x_test, y_train, y_test = train_test_split(xx, lab, train_size=tr)
    encoder = qg.BinaryPhaseEncoding(ancilla=True)
    # model = qg.BinaryPerceptron()
    model = qg.BinaryPerceptron(weights=weights+GHO.algm())
    measurement = qg.ProbabilityThreshold(qubits=2,
                                          p_zero=False,
                                          threshold=0.3,
                                          labels=[0, 1, 2, 3, 4],
                                          observable=qg.Observable.X())

    x_test=np.resize(x_test,(len(x_test),4))
    # y_test = np.resize(y_test, (1000, ))
    result = qg.run(x_test, encoder, model,y_test, measurement)
    predict = predict_class_(result,y_test)
    target = np.concatenate((y_train, y_test))
    y_train = np.resize(y_train,(len(y_train),))
    tp, tn, fn, fp = 0, 0, 0, 0
    uni = np.unique(target)
    for j in range(len(uni)):
        c = uni[j]
        for i in range(len(target)):
            if target[i] == c and predict[i] == c:
                tp += 1
            if target[i] != c and predict[i] != c:
                tn += 1
            if (target[i] == c and predict[i] != c):
                fn += 1
            if (target[i] != c and predict[i] == c):
                fp += 1

    Acc = (tp + tn) / (tn + tp + fn + fp)  # accuracy
    Sen = (tp) / (tp + fn)  # sensitivity
    Spe = (tn) / (tn + fp)  # specificity
    acc.append(Acc)
    sen.append(Sen)
    spe.append(Spe)